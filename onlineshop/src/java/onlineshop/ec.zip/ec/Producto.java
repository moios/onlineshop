package onlineshop.ec;
public class Producto {

    int id_producto;// (PK)
    String descripción;
    int id_categoria; // (FK)
    int precio_unit;
    int cantidad;
    String imagen;//url de la imagen

    public Producto() {
    }

    public Producto(int id_producto, String descripción, int id_categoria, int precio_unit, int cantidad, String imagen) {
        this.id_producto = id_producto;
        this.descripción = descripción;
        this.id_categoria = id_categoria;
        this.precio_unit = precio_unit;
        this.cantidad = cantidad;
        this.imagen = imagen;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public String getDescripción() {
        return descripción;
    }

    public void setDescripción(String descripción) {
        this.descripción = descripción;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public int getPrecio_unit() {
        return precio_unit;
    }

    public void setPrecio_unit(int precio_unit) {
        this.precio_unit = precio_unit;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    
}
