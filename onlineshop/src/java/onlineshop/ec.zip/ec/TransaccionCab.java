
package onlineshop.ec;

import java.sql.Date;

public class TransaccionCab {
int id_transaccion; // (PK)
Date Fecha;
int id_usuario; // (FK)
int total;
String direccion_envio;
int id_medio_pago; //0 Efectivo, 1 Tarjeta de Credito
int NroTarjeta; //solo si id_medio_pago == 1
String estado; //I Ingresado

    public TransaccionCab() {
    }
    public TransaccionCab(int id_transaccion, Date Fecha, int id_usuario, int total, String direccion_envio, int id_medio_pago, int NroTarjeta, String estado) {
        this.id_transaccion = id_transaccion;
        this.Fecha = Fecha;
        this.id_usuario = id_usuario;
        this.total = total;
        this.direccion_envio = direccion_envio;
        this.id_medio_pago = id_medio_pago;
        this.NroTarjeta = NroTarjeta;
        this.estado = estado;
    }

    public int getId_transaccion() {
        return id_transaccion;
    }

    public void setId_transaccion(int id_transaccion) {
        this.id_transaccion = id_transaccion;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getDireccion_envio() {
        return direccion_envio;
    }

    public void setDireccion_envio(String direccion_envio) {
        this.direccion_envio = direccion_envio;
    }

    public int getId_medio_pago() {
        return id_medio_pago;
    }

    public void setId_medio_pago(int id_medio_pago) {
        this.id_medio_pago = id_medio_pago;
    }

    public int getNroTarjeta() {
        return NroTarjeta;
    }

    public void setNroTarjeta(int NroTarjeta) {
        this.NroTarjeta = NroTarjeta;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
}
