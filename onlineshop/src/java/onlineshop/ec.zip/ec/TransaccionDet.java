
package onlineshop.ec;

public class TransaccionDet {
    int id_transaccion; // (PK)
    int item; // (PK)
    int id_producto;
    int cantidad;
    int precio;
    int subTotal;

    public TransaccionDet() {
    }

    public TransaccionDet(int id_transaccion, int item, int id_producto, int cantidad, int precio, int subTotal) {
        this.id_transaccion = id_transaccion;
        this.item = item;
        this.id_producto = id_producto;
        this.cantidad = cantidad;
        this.precio = precio;
        this.subTotal = subTotal;
    }

    public int getId_transaccion() {
        return id_transaccion;
    }

    public void setId_transaccion(int id_transaccion) {
        this.id_transaccion = id_transaccion;
    }

    public int getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(int subTotal) {
        this.subTotal = subTotal;
    }
    
}
